package com.autoflex.leandro.production;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductionControlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
